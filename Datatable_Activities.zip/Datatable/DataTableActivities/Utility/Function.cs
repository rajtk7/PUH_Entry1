﻿namespace Utility.Enum
{
    public enum Function
    {
        None = 0,
        Sum = 1,
        Count = 2,
        Maximum = 3,
        Minimum = 4,
        Average = 5
    }
}
